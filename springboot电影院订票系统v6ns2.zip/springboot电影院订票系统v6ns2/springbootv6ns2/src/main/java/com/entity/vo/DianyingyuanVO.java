package com.entity.vo;

import com.entity.DianyingyuanEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 电影院
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-07-30 23:57:18
 */
public class DianyingyuanVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 影院规模
	 */
	
	private String yingyuanguimo;
		
	/**
	 * 图片
	 */
	
	private String tupian;
		
	/**
	 * 影院地址
	 */
	
	private String yingyuandizhi;
		
	/**
	 * 咨询电话
	 */
	
	private String zixundianhua;
		
	/**
	 * 正在热播
	 */
	
	private String zhengzairebo;
		
	/**
	 * 影院介绍
	 */
	
	private String yingyuanjieshao;
				
	
	/**
	 * 设置：影院规模
	 */
	 
	public void setYingyuanguimo(String yingyuanguimo) {
		this.yingyuanguimo = yingyuanguimo;
	}
	
	/**
	 * 获取：影院规模
	 */
	public String getYingyuanguimo() {
		return yingyuanguimo;
	}
				
	
	/**
	 * 设置：图片
	 */
	 
	public void setTupian(String tupian) {
		this.tupian = tupian;
	}
	
	/**
	 * 获取：图片
	 */
	public String getTupian() {
		return tupian;
	}
				
	
	/**
	 * 设置：影院地址
	 */
	 
	public void setYingyuandizhi(String yingyuandizhi) {
		this.yingyuandizhi = yingyuandizhi;
	}
	
	/**
	 * 获取：影院地址
	 */
	public String getYingyuandizhi() {
		return yingyuandizhi;
	}
				
	
	/**
	 * 设置：咨询电话
	 */
	 
	public void setZixundianhua(String zixundianhua) {
		this.zixundianhua = zixundianhua;
	}
	
	/**
	 * 获取：咨询电话
	 */
	public String getZixundianhua() {
		return zixundianhua;
	}
				
	
	/**
	 * 设置：正在热播
	 */
	 
	public void setZhengzairebo(String zhengzairebo) {
		this.zhengzairebo = zhengzairebo;
	}
	
	/**
	 * 获取：正在热播
	 */
	public String getZhengzairebo() {
		return zhengzairebo;
	}
				
	
	/**
	 * 设置：影院介绍
	 */
	 
	public void setYingyuanjieshao(String yingyuanjieshao) {
		this.yingyuanjieshao = yingyuanjieshao;
	}
	
	/**
	 * 获取：影院介绍
	 */
	public String getYingyuanjieshao() {
		return yingyuanjieshao;
	}
			
}
